import  React from 'react';
// import { store } from './redux/store';
// import { Provider } from 'react-redux';
// Screens
import MainNavigator from './src/Navigation/MainNavigator';



const App = () => {
  return <MainNavigator />;
};



export default App;
